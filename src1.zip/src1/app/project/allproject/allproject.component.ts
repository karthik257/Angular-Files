import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-allproject',
  templateUrl: './allproject.component.html',
  styleUrls: ['./allproject.component.css']
})
export class AllprojectComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
