import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pms',
  templateUrl: './pms.component.html',
  styleUrls: ['./pms.component.css']
})
export class PmsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
