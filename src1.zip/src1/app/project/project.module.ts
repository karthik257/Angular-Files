import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PmsComponent } from './pms/pms.component';
import { NewprojectComponent } from './newproject/newproject.component';
import { AllprojectComponent } from './allproject/allproject.component';

import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';



@NgModule({
  declarations: [PmsComponent, NewprojectComponent, AllprojectComponent],
  imports: [
    CommonModule,
    HttpClientModule,
    FormsModule,
    RouterModule
  ]
})
export class ProjectModule { }
