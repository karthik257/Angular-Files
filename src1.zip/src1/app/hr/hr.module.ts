import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HrmComponent } from './hrm/hrm.component';
import { SalaryComponent } from './salary/salary.component';
import { LeaveComponent } from './leave/leave.component';
import { EmployeeComponent } from './employee/employee.component';
import { PayslipComponent } from './payslip/payslip.component';

import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';


@NgModule({
  declarations: [HrmComponent, SalaryComponent, LeaveComponent, EmployeeComponent, PayslipComponent],
  imports: [
    CommonModule,
    HttpClientModule,
    FormsModule,
    RouterModule
  ]
})
export class HrModule { }
