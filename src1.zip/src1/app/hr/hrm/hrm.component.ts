import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hrm',
  templateUrl: './hrm.component.html',
  styleUrls: ['./hrm.component.css']
})
export class HrmComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
