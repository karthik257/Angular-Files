import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-validation',
  templateUrl: './validation.component.html',
  styleUrls: ['./validation.component.css']
})
export class ValidationComponent implements OnInit {

  myform:FormGroup;
  pagesubmit:boolean=false;

  constructor(private myobj:FormBuilder) { }

  ngOnInit() {
    this.myform=this.myobj.group({
      fname: ["", Validators.required],
      address: ["", Validators.required],
      gender: ["", Validators.required],
      city: ["", Validators.required],
      pincode: ["", Validators.required],
      mobile: ["", [Validators.required, Validators.min(1111111111)]],
      emailid: ["", [Validators.required,Validators.email]]
    });
  }

  save()
  {
    this.pagesubmit=true;
    if(this.myform.invalid)
    {
      return;
    }
    else
    {
      alert("All is well");
    }
  }

}
