import {Routes} from '@angular/router';

import { DashboardComponent } from './dashboard/dashboard.component';
import { BlogComponent } from './blog/blog.component';
import { GalleryComponent } from './gallery/gallery.component';
import { ValidationComponent } from './validation/validation.component';


// hr module
import { HrmComponent } from './hr/hrm/hrm.component';
import { SalaryComponent } from './hr/salary/salary.component';
import { LeaveComponent } from './hr/leave/leave.component';
import { EmployeeComponent } from './hr/employee/employee.component';
import { PayslipComponent } from './hr/payslip/payslip.component';

// project module
import { PmsComponent } from './project/pms/pms.component';
import { NewprojectComponent } from './project/newproject/newproject.component';
import { AllprojectComponent } from './project/allproject/allproject.component';

export const mypage:Routes=[
    { path: "dashboard", component: DashboardComponent},
    { path: "blog", component: BlogComponent},
    { path: "gallery", component: GalleryComponent},
    { path: "validation", component: ValidationComponent},
    { path: "hr", component: HrmComponent, children:[
        { path: "salary", component: SalaryComponent},
        { path: "leave", component: LeaveComponent},
        { path: "employee", component: EmployeeComponent},
        { path: "payslip", component: PayslipComponent}
    ]},
    { path: "gallery", component: GalleryComponent},
    { path: "project", component: PmsComponent,children:[
        { path: "newproject", component: NewprojectComponent },
        { path: "allproject", component: AllprojectComponent }
    ]},

    {path:"",redirectTo:"dashboard",pathMatch:"full"}
];