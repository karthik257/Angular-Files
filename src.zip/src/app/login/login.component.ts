import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private obj:HttpClient) { }

  ngOnInit() {
  }

  blockstatus:boolean=true; //show login

  enableblock(blockname:string){

    if (blockname=="new") {
      this.blockstatus=false; //show signup
      
    }

    if (blockname == "old") {
      this.blockstatus = true; //hide signup and show login

    }
  }

  email:string;
  pass:string;
  errormsg:string;

  serverRes;

  gologin(){
    if((this.email==undefined)||(this.pass==undefined))
    {
      this.errormsg="Enter Input";
    }
    else{
      
      this.errormsg = "Please wait processing";
      var url = "https://jobswalkin.com/profile/auth.php";
      var input = {
        "email": this.email,
        "password": this.pass
      }

      this.obj.post(url, input).subscribe(
        response => {
          this.serverRes=response as string[];
          if(this.serverRes.id=="")
          {
            this.errormsg = "Invalid or does not exist";
          }
          else{
            this.errormsg = "Welcome, Redirecting...";
            localStorage.setItem("fullname", this.serverRes.name); //store email in cookie
            localStorage.setItem("id", this.serverRes.id); //store id in cookie
            window.location.href = "/dashboard";
          }
        }
      );

      
    }
      
  }

  fname:string;
  mobile:string;
  emailid:string;
  password:string;
  address:string;

  register(){
    var url="https://jobswalkin.com/profile/register.php";
    var input ={
      "name" : this.fname,
      "mobile" : this.mobile,
      "email" : this.emailid,
      "password" : this.password,
      "address" : this.address
    }

    this.obj.post(url,input).subscribe(
      response=>{
        this.blockstatus=true; //to show login block
        this.fname="";
        this.mobile="";
        this.emailid="";
        this.password="";
        this.address="";
        this.errormsg="Register Success. Plase Login...!"
      }
    );
  }
}
