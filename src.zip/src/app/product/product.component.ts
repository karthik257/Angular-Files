import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {

  constructor(private myobj: HttpClient) { }

  ngOnInit() {
    this.getproduct(); //to call on page load
  }
  allproduct:any[]=[];

  getproduct()
  {
    this.myobj.get("./assets/products.json").subscribe(
      response=>{
        this.allproduct=response as string[];
      }
    )
  }
}
