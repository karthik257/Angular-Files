import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  constructor() { }
  name: string
  ngOnInit() {
    this.name = localStorage.getItem("fullname");
  }
  logout(){
    localStorage.setItem("fullname","");
    window.location.href ="http://localhost:4200";
  }
}
