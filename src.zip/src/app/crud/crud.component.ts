import { Component, OnInit, APP_BOOTSTRAP_LISTENER } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-crud',
  templateUrl: './crud.component.html',
  styleUrls: ['./crud.component.css']
})
export class CrudComponent implements OnInit {

  constructor(private obj:HttpClient) { }

  ngOnInit() {
    this.getbook();
  }


  books:any[] = [];

  bookname:string;
  msg:string;
  serverResponse;

  


  getbook(){

    var url = "https://jobswalkin.com/web/booklist.php";

    this.obj.get(url).subscribe(
      response=>{
        this.books=response as string[];
      }
    );
  }

    savebook(){

      if(this.bookid!=0){
        this.updatebook(); //to update the record
      }
      else{
        var url = "https://jobswalkin.com/web/savebook.php";
        var input = { "name": this.bookname };
        this.obj.post(url, input).subscribe(
          response => {
            this.serverResponse = response as string[];
            this.msg = this.serverResponse.status;
            this.bookname = "";
            this.getbook(); //to reload the list

          }
        )
      }
      
    }

  delete(id:number){
    var url = "https://jobswalkin.com/web/deletebook.php";
    var input = { "id": id };
    this.obj.post(url, input).subscribe(
      response => {
        this.serverResponse = response as string[];
        this.msg = this.serverResponse.status;
        this.getbook(); //to reload the list

      }
    )
  }


  btntext: string = "Save Record";
  bookid: number=0;

  edit(id:number){

   this.btntext="Please Wait...";
   this.bookid=id;

    var url = "https://jobswalkin.com/web/editbook.php";
    var input = { "id": id };
    this.obj.post(url, input).subscribe(
      response => {
        this.serverResponse = response as string[];
        this.bookname = this.serverResponse.bookname; //to get the name of current book where u clicked
        this.btntext = "Update Record";

      }
    )


  }

  updatebook(){

    this.btntext = "Please wait processing";
    var url = "https://jobswalkin.com/web/updatebook.php";
    var input = { "name": this.bookname,"id":this.bookid };
    this.obj.post(url, input).subscribe(
      response => {
        this.serverResponse = response as string[];
        this.msg = this.serverResponse.status;
        this.bookname = "";
        this.getbook(); //to reload the list
        this.bookid=0;
        this.btntext="Save Record";

      }
    )
  }

  p: number = 1;
}

// create new project
// install bootstrap
// install search pagination
// create component 
// header (blue) footer dashboard login profile
// add routing
// default is login component
// 

