import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

// for navigation , routing
import { RouterModule, Routes } from "@angular/router";
import { HttpClientModule } from "@angular/common/http";

// for search and filter
import { Ng2SearchPipeModule } from 'ng2-search-filter';//for search filter
import { FormsModule } from "@angular/forms";

// for pagination
import { NgxPaginationModule } from "ngx-pagination";

import { InventoryModule } from "../app/inventory/inventory.module";

import { CustomerModule } from "../app/customer/customer.module";

import { AppComponent } from './app.component';
import { HrComponent } from './hr/hr.component';
import { AdminComponent } from './admin/admin.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { Array1Component } from './array1/array1.component';
import { Array2Component } from './array2/array2.component';
import { MultiarrayComponent } from './multiarray/multiarray.component';
import { SongsComponent } from './songs/songs.component';
import { LeaveComponent } from './hr/leave/leave.component';
import { PayslipComponent } from './hr/payslip/payslip.component';
import { EmpComponent } from './hr/emp/emp.component';
import { SalaryComponent } from './hr/salary/salary.component';
import { NewuserComponent } from './admin/newuser/newuser.component';
import { NewempComponent } from './admin/newemp/newemp.component';
import { NewproductComponent } from './admin/newproduct/newproduct.component';
import { NewclientComponent } from './admin/newclient/newclient.component';
import { JsonComponent } from './json/json.component';
import { LocComponent } from './loc/loc.component';
import { ProductComponent } from './product/product.component';
import { ItemComponent } from './item/item.component';
import { JobComponent } from './job/job.component';
import { CityComponent } from './city/city.component';
import { TransportComponent } from './transport/transport.component';
import { TdetailsComponent } from './tdetails/tdetails.component';
import { KeywordComponent } from './keyword/keyword.component';
import { CrudComponent } from './crud/crud.component';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';

const mypages: Routes = [
  { path: "dashboard", component: DashboardComponent },
  { path: "array-one", component: Array1Component },
  { path: "array-two", component: Array2Component },
  {
    path: "myhr",
    component: HrComponent,
    children: [
      { path: "emp", component: EmpComponent },
      { path: "salary", component: SalaryComponent },
      { path: "leave", component: LeaveComponent },
      { path: "payslip", component: PayslipComponent }
    ]
  },
  {
    path: "myadmin",
    component: AdminComponent,
    children: [
      { path: "newuser", component: NewuserComponent },
      { path: "newemp", component: NewempComponent },
      { path: "newproduct", component: NewproductComponent },
      { path: "newclient", component: NewclientComponent }
    ]
  },
  { path: "mul-array", component: MultiarrayComponent },
  { path: "songs", component: SongsComponent },
  { path: "json", component: JsonComponent },
  { path: "loc", component: LocComponent },
  { path: "product", component: ProductComponent },
  { path: "item", component: ItemComponent },
  { path: "job", component: JobComponent },
  { path: "transport", component: TransportComponent },
  { path: "keyword", component: KeywordComponent },
  { path: "crud", component: CrudComponent }
  // { path: "", redirectTo: "/array-one", pathMatch: "full" } 
];

@NgModule({
  declarations: [
    AppComponent,
    HrComponent,
    AdminComponent,
    HeaderComponent,
    FooterComponent,
    Array1Component,
    Array2Component,
    MultiarrayComponent,
    SongsComponent,
    LeaveComponent,
    PayslipComponent,
    EmpComponent,
    SalaryComponent,
    NewuserComponent,
    NewempComponent,
    NewproductComponent,
    NewclientComponent,
    JsonComponent,
    LocComponent,
    ProductComponent,
    ItemComponent,
    JobComponent,
    CityComponent,
    TransportComponent,
    TdetailsComponent,
    KeywordComponent,
    CrudComponent,
    LoginComponent,
    DashboardComponent
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(mypages),
    InventoryModule,
    CustomerModule,
    HttpClientModule,
    Ng2SearchPipeModule,
    FormsModule,
    NgxPaginationModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule {}
