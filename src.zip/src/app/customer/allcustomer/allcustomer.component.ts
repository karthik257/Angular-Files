import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-allcustomer',
  templateUrl: './allcustomer.component.html',
  styleUrls: ['./allcustomer.component.css']
})
export class AllcustomerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
