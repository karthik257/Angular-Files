import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NewcustomerComponent } from './newcustomer/newcustomer.component';
import { AllcustomerComponent } from './allcustomer/allcustomer.component';



@NgModule({
  declarations: [NewcustomerComponent, AllcustomerComponent],
  imports: [
    CommonModule
  ]
})
export class CustomerModule { }
