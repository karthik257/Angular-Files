import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-newcustomer',
  templateUrl: './newcustomer.component.html',
  styleUrls: ['./newcustomer.component.css']
})
export class NewcustomerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
