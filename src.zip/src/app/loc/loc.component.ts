import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loc',
  templateUrl: './loc.component.html',
  styleUrls: ['./loc.component.css']
})
export class LocComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  locarr:any[]=[
    {"state":"Karnataka","city":"Bangalore","population":1000,"radius":100},
    {"state":"Maharastra","city":"Mumbai","population":2000,"radius":200},
    {"state":"Uttar Pradesh","city":"Kashi","population":3000,"radius":300},
    {"state":"Madya Pradesh","city":"Rajasthan","population":4000,"radius":400},
    {"state":"Bihar","city":"Patna","population":5000,"radius":500}
  ];

  // arr:any[]=[];

  save(s:string,c:string,p:number,r:number)
  {
    var newitem = { "state":s, "city":c, "population":p,"radius":r };

    this.locarr = this.locarr.concat(newitem); 
  }


}
