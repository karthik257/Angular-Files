import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-multiarray',
  templateUrl: './multiarray.component.html',
  styleUrls: ['./multiarray.component.css']
})
export class MultiarrayComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  cat:any[]=[
    {"name":"Mobile",
      "product":["Mobile 1","Mobile 2","Mobile 3"]
    },
    {
      "name": "Clothes",
      "product": ["Cloth 1", "Cloth 2", "Cloth 3",]
    },
    {
      "name": "Laptop",
      "product": ["Laptop 1", "Laptop 2"]
    },
    {
      "name": "Food",
      "product": ["Food 1", "Food 2", "Food 3", "Food 4"]
    },
    {
      "name": "Books",
      "product": ["PHP", "Java", "HTML","Python","ASP"],
    }
  ];

  myproduct:any[];

  getproduct(index:number)
  {
    this.myproduct=this.cat[index].product;
  }

  getuser(index: number) {
    this.myproduct = this.loc[index].user;
  }

  loc:any[]=[
    {"name":"Marathahalli","user":["User1","User2","User3"]},
    {"name":"Silk Board","user":["User11","User22","User33","User44"]},
    {"name":"Whitefield","user":["User33","User44","User55"]},
  ];
}
