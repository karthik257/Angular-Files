import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MultiarrayComponent } from './multiarray.component';

describe('MultiarrayComponent', () => {
  let component: MultiarrayComponent;
  let fixture: ComponentFixture<MultiarrayComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MultiarrayComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MultiarrayComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
