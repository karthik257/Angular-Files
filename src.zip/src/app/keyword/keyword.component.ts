import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: "app-keyword",
  templateUrl: "./keyword.component.html",
  styleUrls: ["./keyword.component.css"]
})
export class KeywordComponent implements OnInit {
  constructor(private obj: HttpClient) {}

  ngOnInit() {
    this.getkeyword();
  }

  arr: any[] = [];

  getkeyword() {
    var url = "https://jobswalkin.com/api/getkeyword";

    this.obj.get(url).subscribe(response => {
      this.arr = response as string[];
    });
  }
  p: number = 2; // default page number
  keyword: string; // searching purpose
}
