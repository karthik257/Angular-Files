import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-city',
  templateUrl: './city.component.html',
  styleUrls: ['./city.component.css']
})
export class CityComponent implements OnInit {

  constructor(private myobj:HttpClient) { }

  ngOnInit() {
    this.getcity();
  }
  allcity:any[]=[];
  getcity()
  {
    var url = "https://jobswalkin.com/api/getcity";
    this.myobj.get(url).subscribe(
      response => { this.allcity = response as string[];}
    )
}
}