import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  constructor(private obj:HttpClient) { }

  ngOnInit() {
    this.getprofile();
  }

pdata; //profile data

  getprofile() {
    var url = "https://jobswalkin.com/profile/profile.php";
    var input = {
      "id": localStorage.getItem("id")
    }

    this.obj.post(url, input).subscribe(
      response => {
        this.pdata=response as string[]
      }
    );
  }
}
