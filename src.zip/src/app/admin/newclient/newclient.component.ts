import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-newclient',
  templateUrl: './newclient.component.html',
  styleUrls: ['./newclient.component.css']
})
export class NewclientComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
