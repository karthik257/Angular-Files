import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-newemp',
  templateUrl: './newemp.component.html',
  styleUrls: ['./newemp.component.css']
})
export class NewempComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
