import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-array2',
  templateUrl: './array2.component.html',
  styleUrls: ['./array2.component.css']
})
export class Array2Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }
item:any[]=[
  {"name":"Apple","price":200,"qty":51},
  {"name":"Banana","price":40,"qty":5},
  {"name":"Grapes","price":100,"qty":15},
  {"name":"Orange","price":100,"qty":5},
  {"name":"Mango","price":300,"qty":2}
];

  save(n:string, p:number, q:number)
  {
    var newitem={"name":n,"price":p,"qty":q};
    this.item=this.item.concat(newitem); //to combine with old array
  }

  delitem(itemindex:number)
  {
    this.item.splice(itemindex,1);
  }
}
