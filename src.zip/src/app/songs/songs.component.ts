import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-songs',
  templateUrl: './songs.component.html',
  styleUrls: ['./songs.component.css']
})
export class SongsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
 songsarr:any[]=["A","B","C"];

 save(a:string)
 {
  this.songsarr.push(a);
 }

 del(i:number)
 {
   this.songsarr.splice(i,1);
 }
}
