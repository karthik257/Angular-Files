import {Routes} from "@angular/router";

import { HrComponent } from './hr/hr.component';
import { AdminComponent } from './admin/admin.component';
import { Array1Component } from './array1/array1.component';
import { Array2Component } from './array2/array2.component';
import { MultiarrayComponent } from './multiarray/multiarray.component';
import { SongsComponent } from './songs/songs.component';
import { LeaveComponent } from './hr/leave/leave.component';
import { PayslipComponent } from './hr/payslip/payslip.component';
import { EmpComponent } from './hr/emp/emp.component';
import { SalaryComponent } from './hr/salary/salary.component';
import { NewuserComponent } from './admin/newuser/newuser.component';
import { NewempComponent } from './admin/newemp/newemp.component';
import { NewproductComponent } from './admin/newproduct/newproduct.component';
import { NewclientComponent } from './admin/newclient/newclient.component';

const mypages: Routes = [
    { path: "array-one", component: Array1Component },
    { path: "array-two", component: Array2Component },
    {
        path: "myhr", component: HrComponent,
        children: [
            { path: "emp", component: EmpComponent },
            { path: "salary", component: SalaryComponent },
            { path: "leave", component: LeaveComponent },
            { path: "payslip", component: PayslipComponent }
        ]
    },
    {
        path: "myadmin", component: AdminComponent,
        children: [
            { path: "newuser", component: NewuserComponent },
            { path: "newemp", component: NewempComponent },
            { path: "newproduct", component: NewproductComponent },
            { path: "newclient", component: NewclientComponent },
        ]
    },
    { path: "mul-array", component: MultiarrayComponent },
    { path: "songs", component: SongsComponent },
    { path: "", redirectTo: "/array-one", pathMatch: "full" } //for default landing page

];