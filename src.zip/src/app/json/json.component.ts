import { Component, OnInit } from '@angular/core';
import {HttpClient} from '@angular/common/http';

@Component({
  selector: 'app-json',
  templateUrl: './json.component.html',
  styleUrls: ['./json.component.css']
})
export class JsonComponent implements OnInit {

  constructor(private myobj: HttpClient) { }

  ngOnInit() {
    this.getuser();
    // this.getuser2();
  }
  myuser:any[];
  myuser2:any[]=[];
  getuser()
  {
    this.myobj.get("./assets/user.json").subscribe(
      response=>{
        this.myuser=response as string[]; // to convert from json to array
      }
    )
  }

  getuser2() {
    this.myobj.get("./assets/user2.json").subscribe(
      response => {
        this.myuser2 = response as string[]; // to convert from json to array
      }
    )
  }
}
