import { Component, OnInit} from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{

  title = 'my-dream-app';
  userLogin: boolean = false;
  name: string;
  constructor() { }
  
  ngOnInit() {
  
  this.name = localStorage.getItem("fullname");
    if ((this.name == "") || (this.name == null))
  {
    this.userLogin=false;
  }
  else{
    this.userLogin=true;
  }
  }
}