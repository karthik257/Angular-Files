import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProductComponent } from './product/product.component';
import { InvoiceComponent } from './invoice/invoice.component';
import { FinanceComponent } from './finance/finance.component';



@NgModule({
  declarations: [ProductComponent, InvoiceComponent, FinanceComponent],
  imports: [
    CommonModule
  ]
})
export class InventoryModule { }
