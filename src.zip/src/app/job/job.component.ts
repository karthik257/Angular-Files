import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-job',
  templateUrl: './job.component.html',
  styleUrls: ['./job.component.css']
})
export class JobComponent implements OnInit {

  constructor(private myobj:HttpClient) { }

  ngOnInit() {
    this.getarr();
  }

  myarr:any[]=[];

  getarr()
  {
    var url = "https://jobswalkin.com/api/getkeyword";

    this.myobj.get(url).subscribe(
      response=>{
        this.myarr=response as string[];
      }
    )
  }
}
