import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-item',
  templateUrl: './item.component.html',
  styleUrls: ['./item.component.css']
})
export class ItemComponent implements OnInit {

  constructor(private myobj:HttpClient) { }

  ngOnInit() {
    this.getitem();
  }
  allitem:any[]=[];

  getitem()
  {
    var url = "http://cybotrix.com/ios/car.json";

    this.myobj.get(url).subscribe(
      response=>{this.allitem=response as string[];}
    )
  }
  p:number=2;  // default page number
  keyword:string;   // searching purpose
  
}
